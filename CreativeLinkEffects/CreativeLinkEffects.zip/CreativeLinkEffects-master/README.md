
Creative Link Effects
=========
An inspirational collection of experimental link effects mostly using transitions on pseudo-elements.

[article on Codrops](http://tympanus.net/codrops/?p=16182)

[demo](http://tympanus.net/Development/CreativeLinkEffects/)

[LICENSING & TERMS OF USE](http://tympanus.net/codrops/licensing/)